function toggleSnap() {
  var snapEnabled = document
    .getElementById("carousel")
    .classList.toggle("snap");
  document.getElementById("otherSnappingState").innerText = snapEnabled
    ? "off"
    : "on";
}

function toggleDirection() {
  var isVertical = document
    .getElementById("carousel")
    .classList.toggle("vertical");
  document.getElementById("otherScrollState").innerText = isVertical
    ? "horizontal"
    : "vertical";
}
