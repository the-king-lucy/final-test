# Lucy-Jack-Final
Website for showcasing billionaire tax evasion statistics, made with express, javascript, html, css
